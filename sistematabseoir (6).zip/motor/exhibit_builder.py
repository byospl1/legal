"""Construye la tabla de exhibits y las páginas divisorias "EXHIBIT {letra}"
a partir de fragmentos de XML literal capturados una sola vez del .dotx
original (ver plantillas/i589-tab-cover/fragments/), siguiendo las secciones
9 y 10 de la especificación:

- 5 categorías fijas de contenido, con el XML exacto del original (garantiza
  formato idéntico: negritas, subrayados, numerales romanos como texto).
- Un párrafo vacío entre bloques consecutivos (categorías) para que no
  queden pegados visualmente.
- Página divisoria = 3 piezas exactas del original, una unidad completa por
  Tab: párrafo con salto de página, 12 párrafos vacíos estilo Title (truco
  de centrado vertical), párrafo del título "EXHIBIT {letra}".

Cada categoría puede traer más de un documento de evidencia (ej. Country
Conditions = reporte de país + reporte OSAC, cada uno su propio PDF). Cuando
hay evidencia adjunta, la columna PAGES se construye en paralelo a la
columna DESCRIPTION, línea por línea: cada línea de ítem (i., ii., etc.)
muestra el rango de páginas de SU documento; las líneas de subtítulo y los
espaciadores quedan en blanco en esa columna. Sin evidencia adjunta (modo
manual), la columna PAGES muestra una sola línea con el rango completo del
Tab, como antes.
"""

from __future__ import annotations

import re
from pathlib import Path

FRAGMENTS_DIR = Path(__file__).resolve().parent.parent / "plantillas" / "i589-tab-cover" / "fragments"

CATEGORY_FRAGMENTS: dict[str, list[str]] = {
    "i589_application": ["item_i589_application"],
    "country_conditions": ["subtitle_country_conditions", "subitem_country_reports", "subitem_osac"],
    "form_of_identity": ["subtitle_form_of_identity", "item_passport_from"],
    "supplemental_evidence": ["subtitle_supplemental_evidence", "item_declaration"],
    "fee": ["subtitle_fee", "item_fee_receipt", "item_fbi_fingerprint"],
}

CATEGORY_ORDER = ["i589_application", "country_conditions", "form_of_identity", "supplemental_evidence", "fee"]

# Cada categoría puede tener uno o más "documentos" independientes que se
# pueden subir por separado. `frag_index` es la posición dentro de
# CATEGORY_FRAGMENTS[categoria] (y por lo tanto también la posición del
# párrafo correspondiente en la columna PAGES). El orden de esta lista es
# también el orden en el que se concatenan los PDFs subidos dentro de la
# categoría.
ITEMS_POR_CATEGORIA: dict[str, list[dict]] = {
    "i589_application": [
        {"key": "aplicacion", "label": "I-589 Application", "frag_index": 0},
    ],
    "country_conditions": [
        {"key": "country_reports", "label": "Country Reports on Human Rights Practice", "frag_index": 1},
        {"key": "osac", "label": "OSAC Crime and Safety Report", "frag_index": 2},
    ],
    "form_of_identity": [
        {"key": "pasaporte", "label": "Pasaporte del cliente", "frag_index": 1},
    ],
    "supplemental_evidence": [
        {"key": "declaracion", "label": "Declaración + traducción", "frag_index": 1},
    ],
    "fee": [
        {"key": "fee_receipt", "label": "Fee Receipt", "frag_index": 1},
        {"key": "fbi_fingerprint", "label": "FBI Fingerprint", "frag_index": 2},
    ],
}


def _load(name: str) -> str:
    return (FRAGMENTS_DIR / f"{name}.xml").read_text(encoding="utf-8")


def _xml_escape(text: str) -> str:
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
    )


def _set_first_t_text(xml: str, new_text: str) -> str:
    """Reemplaza el contenido del primer <w:t>...</w:t> del fragmento."""
    return re.sub(r"(<w:t[^>]*>)[^<]*(</w:t>)", lambda m: m.group(1) + _xml_escape(new_text) + m.group(2), xml, count=1)


def _replace_in_first_t(xml: str, old: str, new: str) -> str:
    """Reemplaza `old` por `new` (una vez) dentro del primer <w:t> del fragmento."""
    return re.sub(
        r"(<w:t[^>]*>)([^<]*)(</w:t>)",
        lambda m: m.group(1) + m.group(2).replace(old, new, 1) + m.group(3),
        xml,
        count=1,
    )


def _build_category_xml(categoria: str, pais: str | None, anio_cc: str | None, anio_osac: str | None) -> str:
    frag_names = CATEGORY_FRAGMENTS[categoria]
    parts = [_load(n) for n in frag_names]
    if categoria == "form_of_identity":
        if not pais:
            raise ValueError("form_of_identity requiere 'pais'")
        # "Respondent's Passport from," -> "Respondent's Passport from {PAIS}"
        # (se mantiene la coma original, no se agrega una nueva al final)
        parts[1] = _replace_in_first_t(parts[1], "from,", f"from {_xml_escape(pais)}")
    elif categoria == "country_conditions":
        if not pais:
            raise ValueError("country_conditions requiere 'pais'")
        if not anio_cc:
            raise ValueError("country_conditions requiere 'anio_cc'")
        if not anio_osac:
            raise ValueError("country_conditions requiere 'anio_osac'")
        # "Country Conditions and Reports," -> "Country Conditions and Reports, {PAIS}"
        parts[0] = _replace_in_first_t(parts[0], "Reports,", f"Reports, {_xml_escape(pais)}")
        # "i. Country Reports on Human Rights Practice," -> "...Practice, {AÑO}"
        parts[1] = _replace_in_first_t(parts[1], "Practice,", f"Practice, {_xml_escape(anio_cc)}")
        # "ii. OSAC Crime and Safety Reports," -> "...Reports, {AÑO}"
        parts[2] = _replace_in_first_t(parts[2], "Reports,", f"Reports, {_xml_escape(anio_osac)}")
    return "".join(parts)


def build_description_cell_content(
    categorias: list[str], pais: str | None, anio_cc: str | None = None, anio_osac: str | None = None
) -> str:
    spacer = _load("spacer")
    ordered = [c for c in CATEGORY_ORDER if c in categorias]
    blocks = [_build_category_xml(c, pais, anio_cc, anio_osac) for c in ordered]
    return spacer.join(blocks)


def build_pages_cell_content(categorias: list[str], evidencias: dict | None, paginas_fallback: str) -> str:
    """Columna PAGES. Con evidencia adjunta, una línea por cada párrafo de
    DESCRIPTION (en blanco si es subtítulo/no tiene documento propio, con
    "Pgs. X-Y" si es un ítem con archivo adjunto) — así cada documento
    muestra su rango justo junto a su línea. Sin evidencia, una sola línea
    con el rango completo del Tab, como antes."""
    pages_value_tpl = _load("pages_value")

    if not evidencias:
        return _set_first_t_text(pages_value_tpl, f"Pgs. {paginas_fallback}")

    blank = _set_first_t_text(pages_value_tpl, "")
    ordered = [c for c in CATEGORY_ORDER if c in categorias]
    blocks = []
    for cat in ordered:
        frag_names = CATEGORY_FRAGMENTS[cat]
        items_by_frag_index = {item["frag_index"]: item for item in ITEMS_POR_CATEGORIA.get(cat, [])}
        paras = []
        for idx in range(len(frag_names)):
            item = items_by_frag_index.get(idx)
            info = evidencias.get(item["key"]) if item else None
            if info and info.get("pagina_inicio") and info.get("num_paginas"):
                inicio = info["pagina_inicio"]
                fin = inicio + info["num_paginas"] - 1
                texto = f"Pgs. {inicio}" if inicio == fin else f"Pgs. {inicio}-{fin}"
                paras.append(_set_first_t_text(pages_value_tpl, texto))
            else:
                paras.append(blank)
        blocks.append("".join(paras))
    return blank.join(blocks)


def build_exhibit_table(tab_groups: list[dict]) -> str:
    """tab_groups: [{letra, paginas, categorias: [...], pais, anio_cc,
    anio_osac, evidencias: {item_key: {"pagina_inicio": N, "num_paginas": M}, ...}}, ...]"""
    tbl_open = _load("tbl_open")
    tab_header = _load("tab_header_label")
    desc_header = _load("description_header_label")
    pages_header = _load("pages_header_label")

    header_row = (
        "<w:tr>"
        f"<w:tc><w:tcPr><w:tcW w:w=\"1265\" w:type=\"dxa\"/></w:tcPr>{tab_header}</w:tc>"
        f"<w:tc><w:tcPr><w:tcW w:w=\"6300\" w:type=\"dxa\"/></w:tcPr>{desc_header}</w:tc>"
        f"<w:tc><w:tcPr><w:tcW w:w=\"1548\" w:type=\"dxa\"/></w:tcPr>{pages_header}</w:tc>"
        "</w:tr>"
    )

    rows = [header_row]
    tab_value_tpl = _load("tab_value")

    for tg in tab_groups:
        letra_xml = _set_first_t_text(tab_value_tpl, tg["letra"])
        desc_xml = build_description_cell_content(tg["categorias"], tg.get("pais"), tg.get("anio_cc"), tg.get("anio_osac"))
        pages_xml = build_pages_cell_content(tg["categorias"], tg.get("evidencias"), tg["paginas"])
        row = (
            "<w:tr>"
            f"<w:tc><w:tcPr><w:tcW w:w=\"1265\" w:type=\"dxa\"/></w:tcPr>{letra_xml}</w:tc>"
            f"<w:tc><w:tcPr><w:tcW w:w=\"6300\" w:type=\"dxa\"/></w:tcPr>{desc_xml}</w:tc>"
            f"<w:tc><w:tcPr><w:tcW w:w=\"1548\" w:type=\"dxa\"/></w:tcPr>{pages_xml}</w:tc>"
            "</w:tr>"
        )
        rows.append(row)

    return tbl_open + "".join(rows) + "</w:tbl>"


def build_dividers(tab_groups: list[dict]) -> str:
    """Una unidad completa (salto de página + 12 párrafos Title vacíos +
    título "EXHIBIT {letra}") por cada Tab del run, en orden. No se agregan
    saltos de página extra entre unidades: cada una ya trae el suyo."""
    pagebreak = _load("divider_pagebreak")
    empty_title = _load("divider_empty_title")
    title_tpl = _load("divider_exhibit_title")

    units = []
    for tg in tab_groups:
        title_xml = re.sub(
            r"(<w:t[^>]*>)[^<]*(</w:t>)",
            lambda m: m.group(1) + f"“EXHIBIT {_xml_escape(tg['letra'])}”" + m.group(2),
            title_tpl,
            count=1,
        )
        unit = pagebreak + (empty_title * 12) + title_xml
        units.append(unit)
    return "".join(units)
